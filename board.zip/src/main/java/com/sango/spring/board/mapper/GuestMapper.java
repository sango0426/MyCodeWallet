package com.sango.spring.board.mapper;

import java.util.List;

import com.sango.spring.board.dto.GuestDto;

public interface GuestMapper {
	public List<GuestDto> getList();
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);
}
