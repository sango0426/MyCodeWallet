package com.sango.spring.board.dto;

import lombok.Data;

@Data
public class GuestDto {
	private Long bno;
	private String btext;
}