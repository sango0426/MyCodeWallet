package com.sango.spring.board;

public class ConfigBoard {
	
}
