package com.sango.spring.board.service;

import java.util.List;

import com.sango.spring.board.dto.GuestDto;

import lombok.Data;


@Data
public class GuestBox {
	
}
