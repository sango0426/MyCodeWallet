package com.sango.spring.board.service;

import java.util.List;

import com.sango.spring.board.dto.GuestDto;
import com.sango.spring.board.dto.PagingDto;


public interface GuestService {
	public List<GuestDto> getList();
	public GuestDto read(long bno);
	public void del(long bno);
	public void write(GuestDto dto);
	public void modify(GuestDto dto);
}
