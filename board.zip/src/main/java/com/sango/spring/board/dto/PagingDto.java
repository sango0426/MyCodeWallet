package com.sango.spring.board.dto;

import lombok.Data;

@Data
public class PagingDto {
	
}
