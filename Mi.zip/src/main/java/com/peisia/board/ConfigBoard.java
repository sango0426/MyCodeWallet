package com.peisia.board;

public class ConfigBoard {
	// 게시판에서 한 페이지에 표시할 항목 수를 나타내는 정적 변수
	public static int AMOUNT_PER_PAGE = 3;

	// 게시판에서 한 블록에 표시할 페이지 수를 나타내는 정적 변수
	public static int PAGE_PER_BLOCK = 3;
}