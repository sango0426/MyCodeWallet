package com.peisia.dto;

public class MovieDto {
    public BoxOfficeResult boxOfficeResult;

}
