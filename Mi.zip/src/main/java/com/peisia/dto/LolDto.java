package com.peisia.dto;

public class LolDto {
	public String id;
	public String accountId;
	public String puuid;
	public String name;
	public int profileIconId;
	public long revisionDate;
	public int summonerLevel;
	public String leagueId;
	public String queueType;
	public String tier;
	public String rank;
	public String summonerId;
	public String summonerName;
	public int leaguePoints;
	public int wins;
	public int losses;
	public boolean veteran;
	public boolean inactive;
	public boolean freshBlood;
	public boolean hotStreak;
}
