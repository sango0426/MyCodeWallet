package com.peisia.dto;

import java.util.List;

public class BoxOfficeResult {
    public String boxofficeType;
    public String showRange;
    public List<DailyBoxOffice> dailyBoxOfficeList;

}